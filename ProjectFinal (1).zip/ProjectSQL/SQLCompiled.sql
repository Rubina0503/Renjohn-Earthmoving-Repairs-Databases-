----------------------------CREATE AND POPULATE DATABASE--------------------------------
CREATE DATABASE RenJohn2024
ON
(
	NAME = RenJohnDatafile,
	FILENAME = 'C:\Data\RenJohnDatafile.mdf',
	SIZE = 10MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 10MB

)

LOG ON
(
	NAME = RenJohnLogfile,
	FILENAME = 'C:\Data\RenJohnLogfile.ldf',
	SIZE = 10MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 10MB
)

----------------------------------------

USE RenJohn2024

CREATE TABLE tblCustomer
(CustomerID nVarchar(20) PRIMARY KEY,
 BusinessName Varchar(50),
 BusinessAddress nVarchar(50) NOT NULL,
 SpokespersonName Varchar(25),
 SpokespersonSurname Varchar(25),
 ContactNumber nVarchar(10) NOT NULL,
 Balance INT,
 VATNumber nChar(10) UNIQUE NOT NULL
 )
 CREATE TABLE tblServiceableParts
(PartID nVarchar(20) PRIMARY KEY,
 PartNumber nVarchar(50) UNIQUE NOT NULL,
 PartName nVarchar(50) UNIQUE NOT NULL,
 PartDescription nVarchar(200),
 )
 CREATE TABLE tblJobs
(JobID nVarchar(20) PRIMARY KEY,
 JobName Varchar(25) UNIQUE NOT NULL,
 [Description] nVarchar(200),
 )
 CREATE TABLE tblEmployee
(EmployeeID nVarchar(20) PRIMARY KEY,
 FirstName Varchar(25),
 LastName Varchar(25),
 DOB Date,
 JobID nVarchar(20) FOREIGN KEY REFERENCES tblJobs(JobID) NOT NULL,
 DateHired Date
 )
 CREATE TABLE tblSupplier
(SupplierID nVarchar(20) PRIMARY KEY,
 SupplierName nVarchar(50) NOT NULL,
 [Address] nVarchar(50),
 ContactNumber nVarchar(10) NOT NULL,
 SpokespersonName Varchar(25),
 SpokespersonSurname Varchar(25),
 VATNumber nVarchar(10) NOT NULL
 )
 CREATE TABLE tblMaterial
(MaterialID nVarchar(20) PRIMARY KEY,
 MaterialNumber nVarchar(50) UNIQUE  NOT NULL,
 MaterialName nVarchar(50) UNIQUE  NOT NULL,
 [Description] nVarchar(200),
 )
 CREATE TABLE tblReplacementParts
(PartID nVarchar(20) PRIMARY KEY,
 PartNumber nVarchar(50) UNIQUE  NOT NULL,
 PartDescription nVarchar(200) UNIQUE,
 SupplierID nVarchar(20) FOREIGN KEY REFERENCES tblSupplier(SupplierID)  NOT NULL,
 AdditionalMaterial nVarchar(20) FOREIGN KEY REFERENCES tblMaterial(MaterialID)
 )
 CREATE TABLE tblMachines
(MachineID nVarchar(20) PRIMARY KEY,
 MachineName nVarchar(25) UNIQUE  NOT NULL,
 [Description] nVarchar(200),
 LastServiceDate Date
 )
 CREATE TABLE tblService
(ServiceID nVarchar(20) PRIMARY KEY,
 [Description] nVarchar(200)  NOT NULL,
 EmployeeID nVarchar(20) FOREIGN KEY REFERENCES tblEmployee(EmployeeID)  NOT NULL,
 ReplacementPartID nVarchar(20) FOREIGN KEY REFERENCES tblReplacementParts(PartID)  NOT NULL,
 MachineID nVarchar(20) FOREIGN KEY REFERENCES tblMachines(MachineID)
 )
CREATE TABLE tblOrder
(OrderID nVarchar(20) PRIMARY KEY,
 CustomerID nVarchar(20) FOREIGN KEY REFERENCES tblCustomer(CustomerID)  NOT NULL,
 PartID nVarchar(20) FOREIGN KEY REFERENCES tblServiceableParts(PartID)  NOT NULL,
 ServiceID nVarchar(20) FOREIGN KEY REFERENCES tblService(ServiceID)  NOT NULL,
 DateAcquired Date  NOT NULL,
 ServiceStart Date,
 ServiceEnd Date,
 AmountDue INT  NOT NULL,
 AmountPaid INT
)





------------------------------------------------------------------------


INSERT INTO dbo.tblOrder /*Simmilar queries were used to insert dummy data into other tables, however including those queries would clutter the file*/
Values

	--All data seen here is included within the database
    ('ORD-001', 'CU-ABC01', 'PART-EARTH001', 'SERV-001', '2023-02-05', '2023-02-10', '2023-02-15', 7500, 7500),
    ('ORD-002', 'CU-ACME06', 'PART-EARTH004', 'SERV-002', '2023-03-15', '2023-03-20', '2023-04-05', 12000, 11000),
    ('ORD-003', 'CU-INNO11', 'PART-EARTH002', 'SERV-003', '2023-04-25', '2023-04-30', '2023-05-05', 9500, 9500),
    ('ORD-004', 'CU-INNO11', 'PART-EARTH003', 'SERV-005', '2023-05-10', '2023-05-15', '2023-05-20', 8500, 8000),
    ('ORD-005', 'CU-SPARK15', 'PART-EARTH005', 'SERV-007', '2023-06-20', '2023-06-25', '2023-06-30', 11000, 10500),
    ('ORD-006', 'CU-EDGE17', 'PART-ENG001', 'SERV-010', '2023-07-05', '2023-07-10', '2023-07-15', 9000, 9000),
    ('ORD-007', 'CU-UNIQUE24', 'PART-AIRCRAFT002', 'SERV-008', '2023-08-15', '2023-08-20', '2023-08-25', 13500, 13000),
    ('ORD-008', 'CU-SPARK15', 'PART-ENG004', 'SERV-006', '2023-09-10', '2023-09-15', '2023-09-20', 7800, 7500),
    ('ORD-009', 'CU-UNIQUE24', 'PART-AIRCRAFT003', 'SERV-004', '2023-10-20', '2023-10-25', '2023-10-30', 9500, 9000),
    ('ORD-010', 'CU-UNIVERSAL25', 'PART-ENG003', 'SERV-009', '2023-11-05', '2023-11-10', '2023-11-15', 8500, 8500);

-------------------------------QUERIES-----------------------------------------------

/*COMMON TABLE EXPRESSION*/
WITH EmployeeJobs_CTE 
AS
(SELECT tblEmployee.FirstName, tblEmployee.LastName, tblEmployee.DateHired, tblJobs.JobID, tblJobs.JobName, tblJobs.Description
FROM tblEmployee
FULL OUTER JOIN tblJobs ON tblEmployee.JobID = tblJobs.JobID
)

SELECT FirstName, LastName, DateHired, JobName, Description
FROM EmployeeJobs_CTE

GO

/*CASE*/
SELECT  tblCustomer.BusinessName,tblOrder.AmountDue, tblOrder.AmountPaid, (tblOrder.AmountDue- tblOrder.AmountPaid) AS BalanceDue,

CASE

WHEN (tblOrder.AmountDue- tblOrder.AmountPaid) > 0 THEN 'Customer has an outstanding balance, please make sure it is paid before order is processed'
WHEN (tblOrder.AmountDue- tblOrder.AmountPaid) < 0 THEN 'Customer is owed change, please attatch change with order' 
WHEN (tblOrder.AmountDue- tblOrder.AmountPaid) = 0 THEN 'Customer balance is up to date, ORDER WILL BE PROCESSED SOON'
ELSE 'Customer has not made an Order yet'

END AS OrderStatus

FROM tblCustomer
FULL OUTER JOIN tblOrder ON tblOrder.CustomerID = tblCustomer.CustomerID
GO

/*VIEW 1*/
CREATE VIEW vOldEmployees
AS
SELECT tblEmployee.FirstName, tblEmployee.LastName, tblJobs.JobName,DATEDIFF(year, tblEmployee.DateHired, getdate())AS  NumberOfYearsEmployeed
FROM tblEmployee
FULL OUTER JOIN tblJobs ON tblEmployee.JobID = tblJobs.JobID 
WHERE DATEDIFF(year, tblEmployee.DateHired, getdate()) >3

SELECT * FROM vOldEmployees

GO

/*VIEW 2*/
CREATE VIEW vCustomerServiceDays
AS
SELECT tblCustomer.CustomerID, tblCustomer.BusinessName, DATEDIFF(DAY, tblOrder.ServiceStart, tblOrder.ServiceEnd) AS NumberOfServiceDays
FROM tblCustomer
FULL OUTER JOIN tblOrder ON tblCustomer.CustomerID = tblOrder.CustomerID

SELECT * FROM vCustomerServiceDays

GO

/*CURSOR AS STORED PROCEDURE*/
CREATE PROCEDURE CustomersAmountsDue
AS

DECLARE CustomerCursor CURSOR FOR
SELECT CustomerID, BusinessName, SpokespersonName, SpokespersonSurname, Balance
FROM tblCustomer

DECLARE @CustomerID NVARCHAR
DECLARE @BusinessName VARCHAR(50)
DECLARE @SpokespersonName VARCHAR(25)
DECLARE @SpokespersonSurname VARCHAR(25)
DECLARE @Balance INT

OPEN CustomerCursor 

FETCH NEXT FROM CustomerCursor INTO @CustomerID, @BusinessName, @SpokespersonName, @SpokespersonSurname, @Balance

WHILE @@FETCH_STATUS =  0

BEGIN

	PRINT 'Customer:' + @BusinessName + ' Spokesperson Name:' + @SpokespersonName + '  Spokesperson Surname:' +  @SpokespersonSurname + '  Balance Due:' + 'R' +  CONVERT(VARCHAR, @Balance)

	FETCH NEXT FROM CustomerCursor INTO @CustomerID,@BusinessName,@SpokespersonName, @SpokespersonSurname,@Balance

END



CLOSE CustomerCursor
DEALLOCATE CustomerCursor
GO

---------------------PROCEDURES AND OTHER OBJECTS-------------------------

/*PROCEDURE 1*/
USE RenJohn2024
GO
CREATE PROCEDURE procCheckjob --Shows what job each Employee has 
AS

SELECT EmployeeID,FirstName,LastName,JobName FROM tblEmployee
INNER JOIN tblJobs
ON tblEmployee.JobID  = tblJobs.JobID

EXECUTE procCheckjob 
GO

/*PROCEDURE 2*/
--This Procedure serves to show us which Employee offers which service

CREATE PROCEDURE procService
AS 

SELECT ServiceID,[Description],FirstName,LastName
FROM tblService
INNER JOIN tblEmployee
ON tblService.EmployeeID = tblEmployee.EmployeeID

EXECUTE procService

GO

/*PROCEDURE 3*/
/*THIS STORED PROCEDURE ENCAPSULATES THE INSERT LOGIC SO THAT YOU CAN HAVE REUSABLE CODE AND CALL WHENEVER YOU WANT TO INSERT DATA INTO THE TABLE*/

CREATE PROCEDURE InsertCustomerData
@CustomerID nvarchar(20),
@BusinessName varchar(50),
@BusinessAddress nvarchar(50),
@SpokespersonName varchar(25),
@SpokespersonSurname  varchar(25),
@ContactNumber  nvarchar(10),
@Balance INT, 
@VATNumber NCHAR(10)

AS

BEGIN

INSERT INTO tblCustomer(CustomerID,BusinessName,BusinessAddress,SpokespersonName,SpokespersonSurname,ContactNumber,Balance,VATNumber )
VALUES(@CustomerID,@BusinessName,@BusinessAddress,@SpokespersonName,@SpokespersonSurname,@ContactNumber,@Balance,@VATNumber)

END;

EXECUTE InsertCustomerData @CustomerID = 'CU-ISI101',@BusinessName = 'Innovative Solutions Inc.', @BusinessAddress = '245 Main Street, Cityville',
@SpokespersonName = 'Emily', @SpokespersonSurname = 'Johnson', @ContactNumber = '0825678594', @Balance = 2500, @VATNumber = '321667654' 
GO 

/*Triggers*/

--This table was created to document any changes detected by triggers
CREATE TABLE AuditTrailLog
(ID INT IDENTITY (1,1) PRIMARY KEY,
 Action varchar(50) ,
 TimeInserted datetime 
)

GO

/*INSERT TRIGGER 1*/
CREATE TRIGGER trgInsertSupplier
ON tblSupplier
AFTER INSERT

AS

BEGIN
INSERT INTO AuditTrailLog
VALUES ('Row inserted into Supplier table ', GETDATE())

END;

--INSERT INTO tblSupplier(SupplierID,SupplierName,Address,ContactNumber,SpokespersonName,SpokespersonSurname,VATNumber)
--VALUES ('SUPP-012','Universal Supplies','56 Maple Avenue Oakwood,','0815699982','Regiie','Loki','985123678')

--REMOVE THE COMMENTS FROM THE ABOVE INSERT STATEMENT TO TEST TRIGGER 
GO

/*INSERT TRIGGER 2*/
CREATE TRIGGER trgInsertServicealeParts
ON tblServiceableParts
AFTER INSERT

AS 

BEGIN
INSERT INTO AuditTrailLog
VALUES ('Row inserted in ServiceableParts table ', GETDATE())
END;

--INSERT INTO tblServiceableParts(PartID, PartNumber,PartName,PartDescription)
--VALUES ('PART-ENG012','ENG012','Engine Block','Engine block & Cylinders. The engine block is the backbone of the car engine, and is often made out of aluminium or iron.' )

--REMOVE THE COMMENTS FROM THE ABOVE INSERT STATEMENT TO TEST TRIGGER 


GO
/*INSERT TRIGGER 3*/
CREATE TRIGGER trgInsertMachines
ON tblMachines
AFTER INSERT

AS

BEGIN
INSERT INTO AuditTrailLog
VALUES ('Row inserted into Machines table', GETDATE())
END;

--INSERT INTO tblMachines(MachineID,MachineName,Description,LastServiceDate)
--VALUES ('MACH-013','Shredders','All purpose tool','2022-10-15')

--REMOVE THE COMMENTS FROM THE ABOVE INSERT STATEMENT TO TEST TRIGGER 

/*INSERT TRIGGER 4*/
CREATE TRIGGER trgInsertCustomer
ON tblCustomer
FOR INSERT

AS 

BEGIN 
INSERT INTO dbo.AuditTrailLog
VALUES ('Row Inserted ', GETDATE())
END;

--INSERT INTO tblCustomer (CustomerID,BusinessName,BusinessAddress, SpokespersonName,SpokespersonSurname,ContactNumber,Balance,VATNumber)
--VALUES ('CU-ELIT50','Chriscore','8 katalagter', 'Chris', 'WAWA', 0719349223, 1231,121)

--REMOVE THE COMMENTS FROM THE ABOVE INSERT STATEMENT TO TEST TRIGGER 

/*INSERT TRIGGER 5*/
CREATE TRIGGER trgInsertJobs
ON tblJobs
FOR INSERT

AS

BEGIN
INSERT INTO AuditTrailLog
VALUES('Row inserted into Jobs Table', GETDATE())
END;

--INSERT INTO tblJobs(JobID,JobName,Description)
--VALUES ('JOB-SENGD001','Software Engineer', 'Develops the software and tries to automate all the companies proceess and systems')

--REMOVE THE COMMENTS FROM THE ABOVE INSERT STATEMENT TO TEST TRIGGER 
